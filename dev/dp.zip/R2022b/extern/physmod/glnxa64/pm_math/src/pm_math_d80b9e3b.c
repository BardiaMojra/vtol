#include "stddef.h"
#include "stdlib.h"
#include "pm_std.h"
extern double pm_math_kwMWlgVR1IlmY1byW81iKg(double
pm_math_kX_3wpayBuGfayGjLiZlmB,double pm_math_FkicuWr3zNG_VHwcasJgXR);
#include "pm_std.h"
extern real_T pm_math_V6hUjCc3PiCAauyMwJP5nb;extern real_T
pm_math_Vco4W7EuZu4k_1cAN9SDVG;extern real_T pm_math_k9HpTo0HuFt0gDRVyg17Wc;
extern real32_T pm_math__JOzYwXJOmSsiaZ6WMnnZZ;extern real32_T
pm_math_VaGr_igKLHx0bDW9g54I6v;extern real32_T pm_math_kZu0y5Pv4G8tg1EE_V6tGP;
extern void pm_math_F3OoZ1Weno85bujDCIyv_c(void);extern boolean_T
pm_math__LIYjt5pi54rVTuNKI6I5_(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern
boolean_T pm_math_VK2BuaMRCmOxjLjqE4tZMh(real32_T
pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T pm_math__J9snrOx2Cp4dD_e3lGtRm
(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T
pm_math_kwH13YYrpKtAbDLZ9Q_8I9(real32_T pm_math_kg4CyRgbu6OdeewZOel7Qx);
#include "math.h"
#include "pm_std.h"
double pm_math_kwMWlgVR1IlmY1byW81iKg(double pm_math_kX_3wpayBuGfayGjLiZlmB,
double pm_math_FkicuWr3zNG_VHwcasJgXR){double pm_math_FzyLWRgau0pMYq2XSI3ETL;
double a;a=fabs(pm_math_kX_3wpayBuGfayGjLiZlmB);pm_math_FzyLWRgau0pMYq2XSI3ETL
=fabs(pm_math_FkicuWr3zNG_VHwcasJgXR);if(a<pm_math_FzyLWRgau0pMYq2XSI3ETL){a/=
pm_math_FzyLWRgau0pMYq2XSI3ETL;pm_math_FzyLWRgau0pMYq2XSI3ETL*=sqrt(a*a+1.0);}
else if(a>pm_math_FzyLWRgau0pMYq2XSI3ETL){pm_math_FzyLWRgau0pMYq2XSI3ETL/=a;
pm_math_FzyLWRgau0pMYq2XSI3ETL=a*sqrt(pm_math_FzyLWRgau0pMYq2XSI3ETL*
pm_math_FzyLWRgau0pMYq2XSI3ETL+1.0);}else{if(!pm_math__J9snrOx2Cp4dD_e3lGtRm(
pm_math_FzyLWRgau0pMYq2XSI3ETL)){pm_math_FzyLWRgau0pMYq2XSI3ETL=a*
1.4142135623730951;}}return pm_math_FzyLWRgau0pMYq2XSI3ETL;}
