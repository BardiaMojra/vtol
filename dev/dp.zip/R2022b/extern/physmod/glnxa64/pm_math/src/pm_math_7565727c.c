#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
extern real_T pm_math_V6hUjCc3PiCAauyMwJP5nb;extern real_T
pm_math_Vco4W7EuZu4k_1cAN9SDVG;extern real_T pm_math_k9HpTo0HuFt0gDRVyg17Wc;
extern real32_T pm_math__JOzYwXJOmSsiaZ6WMnnZZ;extern real32_T
pm_math_VaGr_igKLHx0bDW9g54I6v;extern real32_T pm_math_kZu0y5Pv4G8tg1EE_V6tGP;
extern void pm_math_F3OoZ1Weno85bujDCIyv_c(void);extern boolean_T
pm_math__LIYjt5pi54rVTuNKI6I5_(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern
boolean_T pm_math_VK2BuaMRCmOxjLjqE4tZMh(real32_T
pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T pm_math__J9snrOx2Cp4dD_e3lGtRm
(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T
pm_math_kwH13YYrpKtAbDLZ9Q_8I9(real32_T pm_math_kg4CyRgbu6OdeewZOel7Qx);
#include "math.h"
real_T pm_math_V6hUjCc3PiCAauyMwJP5nb;real_T pm_math_Vco4W7EuZu4k_1cAN9SDVG;
real_T pm_math_k9HpTo0HuFt0gDRVyg17Wc;real32_T pm_math__JOzYwXJOmSsiaZ6WMnnZZ;
real32_T pm_math_VaGr_igKLHx0bDW9g54I6v;real32_T pm_math_kZu0y5Pv4G8tg1EE_V6tGP
;void pm_math_F3OoZ1Weno85bujDCIyv_c(void){pm_math_k9HpTo0HuFt0gDRVyg17Wc=(
real_T)pmf_get_nan();pm_math_kZu0y5Pv4G8tg1EE_V6tGP=(real32_T)pmf_get_nan();
pm_math_V6hUjCc3PiCAauyMwJP5nb=(real_T)pmf_get_inf();
pm_math__JOzYwXJOmSsiaZ6WMnnZZ=(real32_T)pmf_get_inf();
pm_math_Vco4W7EuZu4k_1cAN9SDVG= -(real_T)pmf_get_inf();
pm_math_VaGr_igKLHx0bDW9g54I6v= -(real32_T)pmf_get_inf();}boolean_T
pm_math__LIYjt5pi54rVTuNKI6I5_(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx){return(
pmf_is_inf(pm_math_kg4CyRgbu6OdeewZOel7Qx)?1U:0U);}boolean_T
pm_math_VK2BuaMRCmOxjLjqE4tZMh(real32_T pm_math_kg4CyRgbu6OdeewZOel7Qx){return
(pmf_is_inf((real_T)pm_math_kg4CyRgbu6OdeewZOel7Qx)?1U:0U);}boolean_T
pm_math__J9snrOx2Cp4dD_e3lGtRm(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx){return(
pmf_is_nan(pm_math_kg4CyRgbu6OdeewZOel7Qx)?1U:0U);}boolean_T
pm_math_kwH13YYrpKtAbDLZ9Q_8I9(real32_T pm_math_kg4CyRgbu6OdeewZOel7Qx){return
(pmf_is_nan((real_T)pm_math_kg4CyRgbu6OdeewZOel7Qx)?1U:0U);}
