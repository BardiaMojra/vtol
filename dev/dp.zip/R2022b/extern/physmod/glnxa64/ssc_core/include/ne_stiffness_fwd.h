#ifndef __ne_stiffness_fwd_h__
#define __ne_stiffness_fwd_h__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
typedef struct NeStiffnessTag NeStiffness;
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __ne_stiffness_fwd_h__ */
