#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "ne_std.h"
typedef struct ssc_core__gGmO67Uzy_Yg1j4Tgxf21 ssc_core_FDsIo_8VzL4t_qzfDJ75HO
;struct ssc_core__gGmO67Uzy_Yg1j4Tgxf21{boolean_T
ssc_core_kl_DW_ItP_GQYuf5d0Vxdx;boolean_T ssc_core_Vesiv0_gXg0M_XD5Q_eXiA;
boolean_T ssc_core_kYRPIC8P4o8CYXme9CRbxR;real_T
ssc_core_kSsQH5I8Tk_lW9d8fx9Lty;size_t ssc_core__lV4aWNmCPpNZ1eHGhAUGx;size_t
ssc_core_F9ST0a3paVSkaXYlWy4lTh;};ssc_core_FDsIo_8VzL4t_qzfDJ75HO const*
ssc_core_FrZn_AlaHt4XXP_Pc_5_3W(void);void ssc_core_FVfouN9e4S_yiXnDsCeVIN(
ssc_core_FDsIo_8VzL4t_qzfDJ75HO const*ssc_core_kv7GnpbgsfSGjTKLxq5SvA);
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);static ssc_core_FDsIo_8VzL4t_qzfDJ75HO*
ssc_core__6HF7LrgXhS_ji8cLknH9T(void){static ssc_core_FDsIo_8VzL4t_qzfDJ75HO
ssc_core_kv7GnpbgsfSGjTKLxq5SvA={true,false,false,1.0e-10,3U,33U};return&
ssc_core_kv7GnpbgsfSGjTKLxq5SvA;}ssc_core_FDsIo_8VzL4t_qzfDJ75HO const*
ssc_core_FrZn_AlaHt4XXP_Pc_5_3W(void){return ssc_core__6HF7LrgXhS_ji8cLknH9T()
;}void ssc_core_FVfouN9e4S_yiXnDsCeVIN(ssc_core_FDsIo_8VzL4t_qzfDJ75HO const*
ssc_core_kv7GnpbgsfSGjTKLxq5SvA){*ssc_core__6HF7LrgXhS_ji8cLknH9T()= *
ssc_core_kv7GnpbgsfSGjTKLxq5SvA;}
