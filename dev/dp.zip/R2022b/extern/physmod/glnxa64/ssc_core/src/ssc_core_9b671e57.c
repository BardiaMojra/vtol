#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "ne_std.h"
typedef enum ssc_core_Fl4xxck9Ytl0eHEKRVGTG6{ssc_core_Vyy7poNUrBGnealG7hwq0_= -
1,ssc_core_kUlslgbdiw4pb5qLYH9bkW,ssc_core_kCg2j7AhCI0YbPLK7Og6ja,
ssc_core_VW98sLLpYtt9b1_EBbQ7d5,ssc_core_V2p6aTpLs2CleaUNXNfIqc}
ssc_core_Fl4xxck9Ytl0eHEKRVGTG6;ssc_core_Fl4xxck9Ytl0eHEKRVGTG6
ssc_core__gEcOIOfwW8SYacdc6Aai_(void);void ssc_core__vXmG_0rKDC6iafWxnd5yX(
ssc_core_Fl4xxck9Ytl0eHEKRVGTG6 ssc_core_VCMJww_KdPWKZDGZRw9nff);
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);static ssc_core_Fl4xxck9Ytl0eHEKRVGTG6*
ssc_core__6HF7LrgXhS_ji8cLknH9T(void){static ssc_core_Fl4xxck9Ytl0eHEKRVGTG6*
ssc_core_FdMZDMv_bUKvhiTUe3y_lO=NULL;if(ssc_core_FdMZDMv_bUKvhiTUe3y_lO==NULL)
{PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=pm_default_allocator();
ssc_core_FdMZDMv_bUKvhiTUe3y_lO=(ssc_core_Fl4xxck9Ytl0eHEKRVGTG6*)((
mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(
ssc_core_Fl4xxck9Ytl0eHEKRVGTG6)),(1)));*ssc_core_FdMZDMv_bUKvhiTUe3y_lO=
ssc_core_kUlslgbdiw4pb5qLYH9bkW;}return ssc_core_FdMZDMv_bUKvhiTUe3y_lO;}
ssc_core_Fl4xxck9Ytl0eHEKRVGTG6 ssc_core__gEcOIOfwW8SYacdc6Aai_(void){return*
ssc_core__6HF7LrgXhS_ji8cLknH9T();}void ssc_core__vXmG_0rKDC6iafWxnd5yX(
ssc_core_Fl4xxck9Ytl0eHEKRVGTG6 ssc_core_VCMJww_KdPWKZDGZRw9nff){*
ssc_core__6HF7LrgXhS_ji8cLknH9T()=ssc_core_VCMJww_KdPWKZDGZRw9nff;}
