#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(
const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_int_vector_fields(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmIntVector*pm_create_int_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm__fSS_VMqhWlobeqe6mQF_x(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_int_vector(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm__jbisDMumXdocXANx5LhhY
(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);
#include "string.h"
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF){size_t n=pm__YmIqNX3g5Sub1vKK1hZQF->mN
;(void)0;;if(n>0&&pm__hARyx1bZBxVj1boVQqdtV->mX!=pm__YmIqNX3g5Sub1vKK1hZQF->mX
){memcpy(pm__hARyx1bZBxVj1boVQqdtV->mX,pm__YmIqNX3g5Sub1vKK1hZQF->mX,n*sizeof(
real_T));}}void pm_VeeoZXnlJQ4u_112lGs8YD(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF){size_t n
=pm__YmIqNX3g5Sub1vKK1hZQF->mN;(void)0;;if(n>0){memcpy(
pm__hARyx1bZBxVj1boVQqdtV->mX,pm__YmIqNX3g5Sub1vKK1hZQF->mX,n*sizeof(int32_T))
;}}void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV
,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF){size_t n=
pm__YmIqNX3g5Sub1vKK1hZQF->mN;(void)0;;if(n>0){memcpy(
pm__hARyx1bZBxVj1boVQqdtV->mX,pm__YmIqNX3g5Sub1vKK1hZQF->mX,n*sizeof(boolean_T
));}}void pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF){size_t
n=pm__YmIqNX3g5Sub1vKK1hZQF->mN;(void)0;;if(n>0){memcpy(
pm__hARyx1bZBxVj1boVQqdtV->mX,pm__YmIqNX3g5Sub1vKK1hZQF->mX,n*sizeof(char));}}
boolean_T pm_FltUsml2sTlHZuCkbw_pdM(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF){(void)
0;;if(pm__hARyx1bZBxVj1boVQqdtV->mN==0){return true;}else{return(memcmp(
pm__hARyx1bZBxVj1boVQqdtV->mX,pm__YmIqNX3g5Sub1vKK1hZQF->mX,
pm__hARyx1bZBxVj1boVQqdtV->mN*sizeof(real_T))==0);}}boolean_T
pm_V8yYQkcd0vp_YaLM_nd75E(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF){(void)0;;if(pm__hARyx1bZBxVj1boVQqdtV->
mN==0){return true;}else{return(memcmp(pm__hARyx1bZBxVj1boVQqdtV->mX,
pm__YmIqNX3g5Sub1vKK1hZQF->mX,pm__hARyx1bZBxVj1boVQqdtV->mN*sizeof(int32_T))==
0);}}boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF){(void)
0;;if(pm__hARyx1bZBxVj1boVQqdtV->mN==0){return true;}else{return(memcmp(
pm__hARyx1bZBxVj1boVQqdtV->mX,pm__YmIqNX3g5Sub1vKK1hZQF->mX,
pm__hARyx1bZBxVj1boVQqdtV->mN*sizeof(boolean_T))==0);}}int_T
pm_create_real_vector_fields(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR){int_T pm_k4M7bSEmThKJbirXUDQgS6=0;
pm_FiALy5LWvv87e9O_pJGWPC->mN=size;if(size==0){pm_FiALy5LWvv87e9O_pJGWPC->mX=
NULL;}else if(!(pm_FiALy5LWvv87e9O_pJGWPC->mX=(real_T*)((
pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(sizeof(
real_T)),(size))))){pm_k4M7bSEmThKJbirXUDQgS6=1;}return
pm_k4M7bSEmThKJbirXUDQgS6;}PmRealVector*pm_create_real_vector(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR){PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC=(PmRealVector*)((pm__8zlSpb2Hixod149p2zadR)->
mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(sizeof(PmRealVector)),(1)));if(
pm_FiALy5LWvv87e9O_pJGWPC){if(pm_create_real_vector_fields(
pm_FiALy5LWvv87e9O_pJGWPC,pm__c6Ltywqrrtqii4hsDTKgz,pm__8zlSpb2Hixod149p2zadR)
){{void*pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};
pm_FiALy5LWvv87e9O_pJGWPC=NULL;}}return pm_FiALy5LWvv87e9O_pJGWPC;}
PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(const PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR){PmRealVector*
pm__nP_wNlJUxWHWLytmZ4pL0=pm_create_real_vector(pm_FiALy5LWvv87e9O_pJGWPC->mN,
pm__8zlSpb2Hixod149p2zadR);(void)0;;pm_rv_equals_rv(pm__nP_wNlJUxWHWLytmZ4pL0,
pm_FiALy5LWvv87e9O_pJGWPC);return pm__nP_wNlJUxWHWLytmZ4pL0;}void
pm_VeffaD_A8DxagH31Usec1H(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){if(pm_FiALy5LWvv87e9O_pJGWPC->mX!=NULL){{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC->mX);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};}}void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){(void)0;;pm_VeffaD_A8DxagH31Usec1H(
pm_FiALy5LWvv87e9O_pJGWPC,pm__8zlSpb2Hixod149p2zadR);{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};}int_T
pm_create_int_vector_fields(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR){int_T pm_k4M7bSEmThKJbirXUDQgS6=0;
pm_FiALy5LWvv87e9O_pJGWPC->mN=size;if(size==0){pm_FiALy5LWvv87e9O_pJGWPC->mX=
NULL;}else if(!(pm_FiALy5LWvv87e9O_pJGWPC->mX=(int_T*)((
pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(sizeof(
int_T)),(size))))){pm_k4M7bSEmThKJbirXUDQgS6=1;}return
pm_k4M7bSEmThKJbirXUDQgS6;}PmIntVector*pm_create_int_vector(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR){PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC=(PmIntVector*)((pm__8zlSpb2Hixod149p2zadR)->
mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(sizeof(PmIntVector)),(1)));if(
pm_FiALy5LWvv87e9O_pJGWPC){if(pm_create_int_vector_fields(
pm_FiALy5LWvv87e9O_pJGWPC,pm__c6Ltywqrrtqii4hsDTKgz,pm__8zlSpb2Hixod149p2zadR)
){{void*pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};
pm_FiALy5LWvv87e9O_pJGWPC=NULL;}}return pm_FiALy5LWvv87e9O_pJGWPC;}PmIntVector
*pm__fSS_VMqhWlobeqe6mQF_x(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR){PmIntVector*pm__nP_wNlJUxWHWLytmZ4pL0=
pm_create_int_vector(pm_FiALy5LWvv87e9O_pJGWPC->mN,pm__8zlSpb2Hixod149p2zadR);
(void)0;;pm_VeeoZXnlJQ4u_112lGs8YD(pm__nP_wNlJUxWHWLytmZ4pL0,
pm_FiALy5LWvv87e9O_pJGWPC);return pm__nP_wNlJUxWHWLytmZ4pL0;}void
pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){if(pm_FiALy5LWvv87e9O_pJGWPC->mX!=NULL){{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC->mX);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};}}void
pm_destroy_int_vector(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){(void)0;;pm_V_eFnKjg5I4Uc1DwG4yU27(
pm_FiALy5LWvv87e9O_pJGWPC,pm__8zlSpb2Hixod149p2zadR);{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};}int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR){int_T pm_k4M7bSEmThKJbirXUDQgS6=0;
pm_FiALy5LWvv87e9O_pJGWPC->mN=size;if(size==0){pm_FiALy5LWvv87e9O_pJGWPC->mX=
NULL;}else if(!(pm_FiALy5LWvv87e9O_pJGWPC->mX=(boolean_T*)((
pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(sizeof(
boolean_T)),(size))))){pm_k4M7bSEmThKJbirXUDQgS6=1;}return
pm_k4M7bSEmThKJbirXUDQgS6;}PmBoolVector*pm__jbisDMumXdocXANx5LhhY(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR){PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC=(PmBoolVector*)((pm__8zlSpb2Hixod149p2zadR)->
mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(sizeof(PmBoolVector)),(1)));if(
pm_FiALy5LWvv87e9O_pJGWPC){if(pm_create_bool_vector_fields(
pm_FiALy5LWvv87e9O_pJGWPC,pm__c6Ltywqrrtqii4hsDTKgz,pm__8zlSpb2Hixod149p2zadR)
){{void*pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};
pm_FiALy5LWvv87e9O_pJGWPC=NULL;}}return pm_FiALy5LWvv87e9O_pJGWPC;}void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){if(pm_FiALy5LWvv87e9O_pJGWPC->mX!=NULL){{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC->mX);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};}}void
pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){(void)0;;pm_kia_QXK77_xDg9M1NzHr3r(
pm_FiALy5LWvv87e9O_pJGWPC,pm__8zlSpb2Hixod149p2zadR);{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};}PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR){PmBoolVector*pm__nP_wNlJUxWHWLytmZ4pL0=
pm__jbisDMumXdocXANx5LhhY(pm_FiALy5LWvv87e9O_pJGWPC->mN,
pm__8zlSpb2Hixod149p2zadR);(void)0;;pm_kpDvbw1GUlp4c5YdnW7V_w(
pm__nP_wNlJUxWHWLytmZ4pL0,pm_FiALy5LWvv87e9O_pJGWPC);return
pm__nP_wNlJUxWHWLytmZ4pL0;}int_T pm_create_char_vector_fields(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR){
int_T pm_k4M7bSEmThKJbirXUDQgS6=0;pm_FiALy5LWvv87e9O_pJGWPC->mN=size;if(size==
0){pm_FiALy5LWvv87e9O_pJGWPC->mX=NULL;}else if(!(pm_FiALy5LWvv87e9O_pJGWPC->mX
=(char*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(
sizeof(char)),(size))))){pm_k4M7bSEmThKJbirXUDQgS6=1;}return
pm_k4M7bSEmThKJbirXUDQgS6;}PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR){PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC=(PmCharVector*)((pm__8zlSpb2Hixod149p2zadR)->
mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(sizeof(PmCharVector)),(1)));if(
pm_FiALy5LWvv87e9O_pJGWPC){if(pm_create_char_vector_fields(
pm_FiALy5LWvv87e9O_pJGWPC,pm__c6Ltywqrrtqii4hsDTKgz,pm__8zlSpb2Hixod149p2zadR)
){{void*pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};
pm_FiALy5LWvv87e9O_pJGWPC=NULL;}}return pm_FiALy5LWvv87e9O_pJGWPC;}void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){if(pm_FiALy5LWvv87e9O_pJGWPC->mX!=NULL){{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC->mX);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};}}void
pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){(void)0;;pm_VH4is_vKxDpFiupATTqV_4(
pm_FiALy5LWvv87e9O_pJGWPC,pm__8zlSpb2Hixod149p2zadR);{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};}int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR){int_T pm_k4M7bSEmThKJbirXUDQgS6=0;
pm_FiALy5LWvv87e9O_pJGWPC->mN=size;if(size==0){pm_FiALy5LWvv87e9O_pJGWPC->mX=
NULL;}else if(!(pm_FiALy5LWvv87e9O_pJGWPC->mX=(size_t*)((
pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(sizeof(
size_t)),(size))))){pm_k4M7bSEmThKJbirXUDQgS6=1;}return
pm_k4M7bSEmThKJbirXUDQgS6;}PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR){PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC=(PmSizeVector*)((pm__8zlSpb2Hixod149p2zadR)->
mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(sizeof(PmSizeVector)),(1)));if(
pm_FiALy5LWvv87e9O_pJGWPC){if(pm_FaBQ30lWObWMi1zpzQ_EZG(
pm_FiALy5LWvv87e9O_pJGWPC,pm__c6Ltywqrrtqii4hsDTKgz,pm__8zlSpb2Hixod149p2zadR)
){{void*pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};
pm_FiALy5LWvv87e9O_pJGWPC=NULL;}}return pm_FiALy5LWvv87e9O_pJGWPC;}void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){if(pm_FiALy5LWvv87e9O_pJGWPC->mX!=NULL){{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC->mX);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};}}void
pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){(void)0;;pm_FlA06lYLRAWkWmGBVmxE1a(
pm_FiALy5LWvv87e9O_pJGWPC,pm__8zlSpb2Hixod149p2zadR);{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm_FiALy5LWvv87e9O_pJGWPC);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};}void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF){size_t n=pm__YmIqNX3g5Sub1vKK1hZQF->mN
;(void)0;;if(n>0){memcpy(pm__hARyx1bZBxVj1boVQqdtV->mX,
pm__YmIqNX3g5Sub1vKK1hZQF->mX,n*sizeof(size_t));}}boolean_T
pm_kJR6lA3GKXdrdqFEbgLIwb(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF){(void)0;;if(pm__hARyx1bZBxVj1boVQqdtV
->mN==0){return true;}else{return(memcmp(pm__hARyx1bZBxVj1boVQqdtV->mX,
pm__YmIqNX3g5Sub1vKK1hZQF->mX,pm__hARyx1bZBxVj1boVQqdtV->mN*sizeof(size_t))==0
);}}
