#ifndef __pm_log_h__
#define __pm_log_h__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
typedef struct NeLoggerBuilderTag NeLoggerBuilder;
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __pm_log_h__ */
