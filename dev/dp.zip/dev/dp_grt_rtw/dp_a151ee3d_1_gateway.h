/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'dp/Solver Configuration'.
 */

#ifndef __dp_a151ee3d_1_gateway_h__
#define __dp_a151ee3d_1_gateway_h__
#ifdef __cplusplus

extern "C"
{

#endif

  extern void dp_a151ee3d_1_gateway(void);

#ifdef __cplusplus

}

#endif
#endif                                 /* #ifndef __dp_a151ee3d_1_gateway_h__ */
