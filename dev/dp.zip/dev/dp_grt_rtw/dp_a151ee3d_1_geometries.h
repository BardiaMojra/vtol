/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'dp/Solver Configuration'.
 */

struct RuntimeDerivedValuesBundleTag;
void dp_a151ee3d_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv);
